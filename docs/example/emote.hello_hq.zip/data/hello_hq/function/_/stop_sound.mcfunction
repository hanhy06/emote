# Project created via BDEngine

execute as @e[tag=hello_hq_root,type=block_display] at @s run tag @s add sound_pause
# Project created via BDEngine

execute as @e[tag=hello_hq_root,type=block_display] at @s run function hello_hq:k/default/keyframe_0

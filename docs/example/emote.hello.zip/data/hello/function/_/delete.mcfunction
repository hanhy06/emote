# Project created via BDEngine

execute as @e[type=minecraft:block_display,tag=hello] on passengers run kill @s
execute as @e[type=minecraft:block_display,tag=hello] run kill @s

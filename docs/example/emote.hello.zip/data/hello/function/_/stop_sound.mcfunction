# Project created via BDEngine

execute as @e[tag=hello_root,type=block_display] at @s run tag @s add sound_pause
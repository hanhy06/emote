# Project created via BDEngine

execute as @e[tag=hello_root,type=block_display] at @s run function hello:k/default/keyframe_0

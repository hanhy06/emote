# Project created via BDEngine

execute as @e[tag=hello_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function hello:k/default/keyframe_23
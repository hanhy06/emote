# Project created via BDEngine

execute as @e[tag=hello_root,type=block_display] if entity @s[tag=animation_loop] at @s run function hello:k/default/keyframe_0
execute as @e[tag=hello_root,type=block_display] unless entity @s[tag=animation_loop] at @s run function hello:_/stop_anim
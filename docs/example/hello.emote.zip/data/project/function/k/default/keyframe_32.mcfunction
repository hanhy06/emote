# Project created via BDEngine
data merge entity @e[type=item_display,tag=project_7,distance=..1,limit=1,sort=nearest] {transformation:[0.4685f,0.0f,0.0f,0.3476815625f,0.0f,0.4685f,0.0f,1.408375f,0.0f,0.0f,0.4685f,-0.0165821875f,0.0f,0.0f,0.0f,1.0f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=project_8,distance=..1,limit=1,sort=nearest] {transformation:[0.4685f,0.0f,0.0f,0.3476815625f,0.0f,0.937f,0.0f,1.174125f,0.0f,0.0f,0.4685f,-0.0165821875f,0.0f,0.0f,0.0f,1.0f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=project_9,distance=..1,limit=1,sort=nearest] {transformation:[0.4685f,0.0f,0.0f,-0.3620959375f,0.0f,0.4685f,0.0f,1.408375f,0.0f,0.0f,0.4685f,-0.0165821875f,0.0f,0.0f,0.0f,1.0f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=project_10,distance=..1,limit=1,sort=nearest] {transformation:[0.4685f,0.0f,0.0f,-0.3620959375f,0.0f,0.937f,0.0f,1.174125f,0.0f,0.0f,0.4685f,-0.0165821875f,0.0f,0.0f,0.0f,1.0f],interpolation_duration:2,start_interpolation:0}
schedule function project:k/default/check_loop 0.1s

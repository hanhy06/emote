# no created via BDEngine
data merge entity @e[type=item_display,tag=no_0,distance=..1,limit=1,sort=nearest] {transformation:[0.6625562828f,-0.171472083f,-0.6399886693f,-0.0856229165f,0.0000263833f,0.9050836977f,-0.2424716467f,1.8568174738f,0.6625618246f,0.1714346083f,0.6399929716f,0.0688423041f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function no:k/default/check_pause_6 0.1s

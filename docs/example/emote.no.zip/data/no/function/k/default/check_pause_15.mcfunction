# no created via BDEngine

execute as @e[tag=no_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function no:k/default/keyframe_16
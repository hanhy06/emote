# no created via BDEngine
data merge entity @e[type=item_display,tag=no_0,distance=..1,limit=1,sort=nearest] {transformation:[0.937f,0f,0f,0.000113125f,0f,0.9050724992f,-0.2425134453f,1.8568118746f,0f,0.2425134453f,0.9050724992f,0.1043817226f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function no:k/default/check_loop 0.1s

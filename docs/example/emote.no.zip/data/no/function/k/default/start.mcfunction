# no created via BDEngine

execute as @e[tag=no_root,type=block_display] at @s run function no:k/default/keyframe_0

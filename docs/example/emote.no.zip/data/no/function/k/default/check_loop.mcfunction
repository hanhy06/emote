# no created via BDEngine

execute as @e[tag=no_root,type=block_display] if entity @s[tag=animation_loop] at @s run function no:k/default/keyframe_0
execute as @e[tag=no_root,type=block_display] unless entity @s[tag=animation_loop] at @s run function no:_/stop_anim
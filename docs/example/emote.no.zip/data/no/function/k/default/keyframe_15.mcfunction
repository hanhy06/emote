# no created via BDEngine
data merge entity @e[type=item_display,tag=no_0,distance=..1,limit=1,sort=nearest] {transformation:[0.8645739157f,-0.1101410362f,-0.3440201978f,-0.0549573931f,0.0079158015f,0.8979429851f,-0.267590612f,1.8532471175f,0.3611347178f,0.2440007125f,0.8294663151f,0.1051253562f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function no:k/default/check_pause_15 0.1s

# no created via BDEngine

execute as @e[type=minecraft:block_display,tag=no] on passengers run kill @s
execute as @e[type=minecraft:block_display,tag=no] run kill @s

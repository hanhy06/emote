# no created via BDEngine

execute as @e[tag=no_root,type=block_display] at @s run tag @s add sound_pause
# cry created via BDEngine

execute as @e[tag=cry_root,type=block_display] at @s run tag @s add sound_pause
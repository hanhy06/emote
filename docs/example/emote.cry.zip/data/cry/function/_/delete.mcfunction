# cry created via BDEngine

execute as @e[type=minecraft:block_display,tag=cry] on passengers run kill @s
execute as @e[type=minecraft:block_display,tag=cry] run kill @s

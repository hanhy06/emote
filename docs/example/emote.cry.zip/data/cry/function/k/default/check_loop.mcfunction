# cry created via BDEngine

execute as @e[tag=cry_root,type=block_display] if entity @s[tag=animation_loop] at @s run function cry:k/default/keyframe_0
execute as @e[tag=cry_root,type=block_display] unless entity @s[tag=animation_loop] at @s run function cry:_/stop_anim
# cry created via BDEngine

execute as @e[tag=cry_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function cry:k/default/keyframe_17
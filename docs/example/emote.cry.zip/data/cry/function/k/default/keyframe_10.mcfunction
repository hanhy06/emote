# cry created via BDEngine
data merge entity @e[type=item_display,tag=cry_0,distance=..1,limit=1,sort=nearest] {transformation:[0.937f,0f,0f,0.000113125f,0f,0.8114658033f,0.4685f,1.6969829017f,0f,-0.4685f,0.8114658033f,-0.1925625f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=cry_7,distance=..1,limit=1,sort=nearest] {transformation:[0.331279527f,0.331279527f,0f,0.3431302188f,0.0857414508f,-0.0857414508f,-0.4525362496f,1.2961723828f,-0.3199914508f,0.3199914508f,-0.1212567226f,-0.0504124096f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
data merge entity @e[type=item_display,tag=cry_8,distance=..1,limit=1,sort=nearest] {transformation:[0.331279527f,0.662559054f,0f,0.1774904553f,0.0857414508f,-0.1714829017f,-0.4525362496f,1.3390431082f,-0.3199914508f,0.6399829017f,-0.1212567226f,-0.2104081351f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
execute as @e[tag=cry_root,type=block_display] at @s positioned ~ ~1.3 ~ run particle minecraft:falling_water ^ ^ ^-0.15 0.1 0.1 0.1 0 3
schedule function cry:k/default/check_pause_10 0.1s

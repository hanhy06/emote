# yes created via BDEngine

execute as @e[tag=yes_root,type=block_display] at @s run function yes:k/default/keyframe_0

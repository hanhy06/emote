# yes created via BDEngine
data merge entity @e[type=item_display,tag=yes_0,distance=..1,limit=1,sort=nearest] {transformation:[0.937f,0f,0f,0.000113125f,0f,0.937f,0f,1.872775625f,0f,0f,0.937f,-0.016875f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function yes:k/default/check_pause_4 0.1s

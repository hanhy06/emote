# yes created via BDEngine

execute as @e[tag=yes_root,type=block_display] unless entity @s[tag=animation_pause] at @s run function yes:k/default/keyframe_5
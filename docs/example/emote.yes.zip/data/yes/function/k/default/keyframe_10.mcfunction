# yes created via BDEngine
data merge entity @e[type=item_display,tag=yes_0,distance=..1,limit=1,sort=nearest] {transformation:[0.937f,0f,0f,0.000113125f,0f,0.8114658033f,0.4685f,1.8100085267f,0f,-0.4685f,0.8114658033f,-0.251125f,0f,0f,0f,1f],interpolation_duration:2,start_interpolation:0}
schedule function yes:k/default/check_pause_10 0.1s

# yes created via BDEngine

execute as @e[type=minecraft:block_display,tag=yes] on passengers run kill @s
execute as @e[type=minecraft:block_display,tag=yes] run kill @s
